<footer>
    <p class="copyright">Copyright© 2018-<?php echo date('Y') ?> | <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> .AllRightsReserved</p>
</footer>
<div class="back-to-top">Top</div>
<script src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/jquery.pjax.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/pure.js"></script>
<script>
    $(function(){
        $(document).pjax("a", '.container', {fragment:'.container', timeout:6000});
    });
</script>
</body>
</html>