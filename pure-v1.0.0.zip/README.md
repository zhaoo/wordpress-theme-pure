# Pure

A pure theme for WordPress.

[![Verson](https://img.shields.io/badge/Release-1.0.0-orange.svg)](https://github.com/izhaoo/pure)
[![PHP](https://img.shields.io/badge/PHP-7.2-blue.svg)](http://www.php.net/ChangeLog-7.php)
[![License](https://img.shields.io/badge/License-MIT-red.svg)](https://mit-license.org/)

* [Demo](https://pure.izhaoo.com)